class Player:
    def play(self):
      print("The player is playing cricket.")

class Batsman(Player):
    def play(self):
      print("The batsman is playing batting")
class Blower(Player):
    def play(self):
      print("The blower is playing bowling")
batsman = Batsman()
blower = Blower()
batsman.play()
blower.play()
